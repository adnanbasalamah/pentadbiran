jQuery(function ($) {
    $(document).ready(function() {
        $('.nama-staff').autocomplete({
            source: Drupal.settings.basePath + 'masterdata/staff/getajax',
            select: function (event, ui) {
                var splitID = $(this).attr('id').split('-');
                if (splitID[4] == 'new'){
                    $('#nidstaff-' + splitID[5] + '-' + splitID[6]).val(ui.item.id);
                    if (ui.item.alamat){
                        $('#'+ splitID[0] +'-'+ splitID[1] +'-'+ splitID[2] +'-alamat-'+ splitID[4] +'-'+ splitID[5] +'-'+ splitID[6]).val(ui.item.alamat);
                    }
                    if (ui.item.telepon){
                        $('#'+ splitID[0] +'-'+ splitID[1] +'-'+ splitID[2] +'-telepon-'+ splitID[4] +'-'+ splitID[5] +'-'+ splitID[6]).val(ui.item.telepon);
                    }
                    if (ui.item.email){
                        $('#'+ splitID[0] +'-'+ splitID[1] +'-'+ splitID[2] +'-email-'+ splitID[4] +'-'+ splitID[5] +'-'+ splitID[6]).val(ui.item.email);
                    }
                }else {
                    $('#nidstaff-' + splitID[4] + '-' + splitID[5]).val(ui.item.id);
                    if (ui.item.alamat){
                        $('#'+ splitID[0] +'-'+ splitID[1] +'-'+ splitID[2] +'-alamat-'+ splitID[4] +'-'+ splitID[5] +'-'+ splitID[6]).val(ui.item.alamat);
                    }
                    if (ui.item.telepon){
                        $('#'+ splitID[0] +'-'+ splitID[1] +'-'+ splitID[2] +'-telepon-'+ splitID[4] +'-'+ splitID[5] +'-'+ splitID[6]).val(ui.item.telepon);
                    }
                    if (ui.item.email){
                        $('#'+ splitID[0] +'-'+ splitID[1] +'-'+ splitID[2] +'-email-'+ splitID[4] +'-'+ splitID[5] +'-'+ splitID[6]).val(ui.item.email);
                    }
                }
            }
        });
        $('.checkdel').on('change', function(e){
            var SplitId = $(this).attr('id').split('-');
            if (this.checked){
                $('#delete-'+ SplitId[1] +'-'+ SplitId[2]).val(1);
            }else{
                $('#delete-'+ SplitId[1] +'-'+ SplitId[2]).val(0);
            }
        });
    });
})